/*!CK:1280342925!*//*1384508459,178150429*/

if (self.CavalryLogger) { CavalryLogger.start_js(["8eJ2b"]); }

__d("legacy:PhotoSnowliftAds",["PhotoSnowliftAds"],function(a,b,c,d){a.PhotoSnowliftAds=b('PhotoSnowliftAds');},3);